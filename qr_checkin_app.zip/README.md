# QR Check-In App

Proyecto de escaneo y control de accesos.
