
import cv2
from pyzbar import pyzbar
import time

ARCHIVO_DB = "usuarios.csv"

def obtener_tiempo_actual():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

def inicializar_bd():
    try:
        with open(ARCHIVO_DB, "x", encoding="utf-8") as f:
            f.write("ID,Nombre,Accesos,Última Entrada,Última Salida\n")
    except Exception:
        pass

def cargar_usuarios():
    usuarios = {}
    try:
        with open(ARCHIVO_DB, "r", encoding="utf-8") as f:
            lineas = f.readlines()[1:]
            for linea in lineas:
                partes = linea.strip().split(",")
                if len(partes) == 5:
                    usuarios[partes[0]] = {
                        "nombre": partes[1],
                        "accesos": int(partes[2]),
                        "ultima_entrada": partes[3],
                        "ultima_salida": partes[4]
                    }
    except Exception:
        pass
    return usuarios

def guardar_usuarios(usuarios):
    try:
        with open(ARCHIVO_DB, "w", encoding="utf-8") as f:
            f.write("ID,Nombre,Accesos,Última Entrada,Última Salida\n")
            for id_pulsera, datos in usuarios.items():
                linea = f"{id_pulsera},{datos['nombre']},{datos['accesos']},{datos['ultima_entrada']},{datos['ultima_salida']}\n"
                f.write(linea)
    except Exception as e:
        print("Error al guardar usuarios:", e)

def registrar_usuario(usuarios):
    id_pulsera = input("Escanear pulsera o ingresar ID único: ").strip()
    if id_pulsera in usuarios:
        print("Esa pulsera ya está registrada.")
        return

    nombre = input("Nombre del usuario: ").strip()
    usuarios[id_pulsera] = {"nombre": nombre, "accesos": 0, "ultima_entrada": "", "ultima_salida": ""}
    guardar_usuarios(usuarios)
    print(f"Usuario {nombre} registrado exitosamente.")

def escanear_qr():
    cap = cv2.VideoCapture(0)
    print("Escanee un código QR...")
    id_detectado = None

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        codigos = pyzbar.decode(frame)
        for codigo in codigos:
            id_detectado = codigo.data.decode("utf-8")
            cv2.rectangle(frame, (codigo.rect.left, codigo.rect.top),
                          (codigo.rect.left + codigo.rect.width, codigo.rect.top + codigo.rect.height),
                          (0, 255, 0), 2)
            cap.release()
            cv2.destroyAllWindows()
            return id_detectado

        cv2.imshow("Escáner QR", frame)
        if cv2.waitKey(1) == 27:
            break

    cap.release()
    cv2.destroyAllWindows()
    return None

def registrar_acceso(usuarios):
    id_pulsera = escanear_qr()
    if id_pulsera and id_pulsera in usuarios:
        usuarios[id_pulsera]["accesos"] += 1
        usuarios[id_pulsera]["ultima_entrada"] = obtener_tiempo_actual()
        guardar_usuarios(usuarios)
        print(f"Acceso registrado para {usuarios[id_pulsera]['nombre']}. Última entrada: {usuarios[id_pulsera]['ultima_entrada']}")
    else:
        print("Pulsera no registrada o escaneo cancelado.")

def registrar_salida(usuarios):
    id_pulsera = escanear_qr()
    if id_pulsera and id_pulsera in usuarios:
        usuarios[id_pulsera]["ultima_salida"] = obtener_tiempo_actual()
        guardar_usuarios(usuarios)
        print(f"Salida registrada para {usuarios[id_pulsera]['nombre']}. Última salida: {usuarios[id_pulsera]['ultima_salida']}")
    else:
        print("Pulsera no registrada o escaneo cancelado.")

def mostrar_usuarios(usuarios):
    print("\n--- Lista de Usuarios ---")
    for id_pulsera, datos in usuarios.items():
        print(f"ID: {id_pulsera} | Nombre: {datos['nombre']} | Accesos: {datos['accesos']} | Últ. Entrada: {datos['ultima_entrada']} | Últ. Salida: {datos['ultima_salida']}")
    print()

def main():
    inicializar_bd()
    usuarios = cargar_usuarios()

    while True:
        print("\n--- MENÚ ---")
        print("1. Registrar nuevo usuario")
        print("2. Registrar acceso (QR)")
        print("3. Registrar salida (QR)")
        print("4. Ver todos los usuarios")
        print("5. Salir")

        opcion = input("Seleccione una opción: ").strip()
        if opcion == "1":
            registrar_usuario(usuarios)
        elif opcion == "2":
            registrar_acceso(usuarios)
        elif opcion == "3":
            registrar_salida(usuarios)
        elif opcion == "4":
            mostrar_usuarios(usuarios)
        elif opcion == "5":
            print("Saliendo...")
            break
        else:
            print("Opción inválida.")

if __name__ == "__main__":
    main()
